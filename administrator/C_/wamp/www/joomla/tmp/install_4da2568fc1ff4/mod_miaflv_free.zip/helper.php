<?php
/*======================================================================*\
|| #################################################################### ||
|| # Copyright (C) 2010   Miaflv.com. All Rights Reserved.            ||
|| # license - PHP files are licensed under  GNU/GPL V2                 ||
|| # license - CSS  - JS - IMAGE files  are Copyrighted material        ||
|| # bound by Proprietary License of Youjoomla LLC                      ||
|| # for more information visit http://www.youjoomla.com/license.html   ||
|| # Redistribution and  modification of this software                  ||
|| # is bounded by its licenses                                         ||
|| # websites - http://www.miaflv.com                                   ||
|| #################################################################### ||
\*======================================================================*/

// no direct access
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.mootools');
$document = &JFactory::getDocument();
class modMiaFlvFreeHelper
{
	function getPlayer(&$params)
	{
		global $mainframe;

$video_link				= $params->get ('video_link');
$video_image			= $params->get ('video_image');
$video_width			= $params->get ('video_width');
$video_height			= $params->get ('video_height');
$start_volume			= $params->get ('start_volume');
// image
$get_miaflv_img = ''.JURI::base().'images/stories/miaflv_media/'.$video_image.'';

// youtube prefix
if (preg_match( "/http/",$video_link) || preg_match( "/https/",$video_link)){
	$youtube_code ='';
}else{
	$youtube_code ='youTube:';
}
$document = &JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'modules/mod_miaflv_free/css/stylesheet.css');
$document->addScript(JURI::base() . 'modules/mod_miaflv_free/src/swfobject.js');
$document->addScript(JURI::base() . 'modules/mod_miaflv_free/src/miaflv.js');

$document->addCustomTag("
<script type=\"text/javascript\">
	
		var flashvarsFree = {id:'MiaFLVFree'};
		var paramsFree = {allowfullscreen : \"true\", wmode:\"opaque\",allowScriptAccess: \"always\"};
		var attributesFree = {id : \"MiaFLVFree\", name : \"MiaFLVFree\"};
		swfobject.embedSWF(\"".JURI::base()."modules/mod_miaflv_free/swf/MiaFLV.swf\", \"playerFree\", \"".$video_width."\", \"".$video_height."\", \"10.0.0\", false , flashvarsFree, paramsFree, attributesFree);
</script>
");
echo("<script type=\"text/javascript\">var movieMiaFLVFree = {movie:'".$youtube_code.$video_link."',volume:".$start_volume.", preview:'".$get_miaflv_img."'};
	 movies.set('MiaFLVFree', movieMiaFLVFree);</script>");
	}
}
?>