<?php
/*======================================================================*\
|| #################################################################### ||
|| # Copyright (C) 2010   Miaflv.com. All Rights Reserved.            ||
|| # license - PHP files are licensed under  GNU/GPL V2                 ||
|| # license - CSS  - JS - IMAGE files  are Copyrighted material        ||
|| # bound by Proprietary License of Youjoomla LLC                      ||
|| # for more information visit http://www.youjoomla.com/license.html   ||
|| # Redistribution and  modification of this software                  ||
|| # is bounded by its licenses                                         ||
|| # websites - http://www.miaflv.com                                   ||
|| #################################################################### ||
\*======================================================================*/
// no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<!-- http://www.miaflv.com  Mia FLV Player Joomla! Module V1.0 for Joomla 1.5 starts here -->
<div class="miaflv_Free miaflv_holder" style=" width:<?php echo $video_width ?>px;height:<?php echo $video_height ?>px;">
	<div class="miaflv_in">
		<div id="playerFree"><a href="http://www.adobe.com/go/getflashplayer">Get Adobe Flash player</a></div>
	</div>
</div>
