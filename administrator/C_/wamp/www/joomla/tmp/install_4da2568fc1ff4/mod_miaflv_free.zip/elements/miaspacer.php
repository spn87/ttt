<?php
/**
 * @package		Extend Elements
 * @website     Miaflv.com 
 * @copyright	Copyright (c)  2010  Miaflv.com .
 * @license     PHP files are GNU/GPL V2. CSS / JS / SWF / IMAGE files are Copyrighted Commercial
 */

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();
  jimport('joomla.filesystem.file');
  jimport('joomla.filesystem.folder');  

/**
 * Renders a spacer element
 *
 * @package 	Joomla.Framework
 * @subpackage		Parameter
 * @since		1.5
 */

class JElementMiaSpacer extends JElement
{
	/**
	* Element name
	*
	* @access	protected
	* @var		string
	*/
	
	var	$_name = 'MiaSpacer';

	function fetchTooltip($label, $description, &$node, $control_name, $name) {
		return '&nbsp;';
			
	}

	function fetchElement($name, $value, &$node, $control_name)
	{
		  $path = JPATH_ROOT.DS."images".DS."stories".DS."miaflv_media"; 
		  JFolder::create($path);
 		  JFile::write($path.DS."index.html", "");
		  
		if ($value) {
		$document =& JFactory::getDocument();
		$document->addCustomTag('
		<style type="text/css">
		.miaspacer_hoder{
			background:#fff;
			padding:5px;
			display:block;
			width:400px;
			text-align:center;
			overflow:hidden;
			border:1px solid #DDDDDD;
		}
		.miaspacer{
			padding:5px;
			background:#DEDEDE;
			border:1px solid #DDDDDD;
			text-shadow:1px 1px #fff;
			font-size:12px;
		}
		#menu-pane input,#menu-pane option,#menu-pane selected{
			height:20px;
			line-height:20px;
			font-size:12px;
			padding:0 0 0 5px;
		}
		#menu-pane .inputbox{
			height:22px;
			line-height:20px;
			font-size:12px;
			}
		#menu-pane input,#menu-pane option{
			margin:0 5px 0 0;
		}
		#menu-pane .text_area{
			font-size:12px;
		}
		#menu-pane .button2-left{
			margin-top:3px;
		}
		</style>
		
		');
			return '<div class="miaspacer_hoder"><div class="miaspacer">'.JText::_($value).'</div></div>';
		} else {
			return '<hr />';
		}
	}
}
