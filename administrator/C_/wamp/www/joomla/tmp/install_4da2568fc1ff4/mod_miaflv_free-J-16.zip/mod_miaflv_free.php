<?php
/*======================================================================*\
|| #################################################################### ||
|| # Copyright (C) 2010   Miaflv.com. All Rights Reserved.            ||
|| # license - PHP files are licensed under  GNU/GPL V2                 ||
|| # license - CSS  - JS - IMAGE files  are Copyrighted material        ||
|| # bound by Proprietary License of Youjoomla LLC                      ||
|| # for more information visit http://www.youjoomla.com/license.html   ||
|| # Redistribution and  modification of this software                  ||
|| # is bounded by its licenses                                         ||
|| # websites - http://www.miaflv.com                                   ||
|| #################################################################### ||
\*======================================================================*/

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (dirname(__FILE__).DS.'helper.php');
$module_template 		=  		$params->get   ('module_template','Default');
$video_link				= $params->get ('video_link');
$video_image			= $params->get ('video_image');
$video_width			= $params->get ('video_width');
$video_height			= $params->get ('video_height');
$start_volume			= $params->get ('start_volume');
$call_mia_flv 			= modMiaFlvFreeHelper::getPlayer($params);
require(JModuleHelper::getLayoutPath('mod_miaflv_free',''.$module_template.'/default'));

?>
